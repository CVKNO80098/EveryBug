//go:build !windows

package main

const (
	dotnetExitCode = 142
)
