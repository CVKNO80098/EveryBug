//go:build windows && 386

package main

const (
	dotnetExitCode = -2147450735
)
